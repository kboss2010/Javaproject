package com.shoot.qa.demoqa;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class App 
{
	public static void main( String[] args )
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rajat\\Desktop\\demoqa\\resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("https://www.shootproof.com");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		
		WebElement getStarted1 = driver.findElement(By.xpath("//a[@class='btn btn-shootproof google-ads-signup-tracking']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", getStarted1);
		System.out.println("Topmost Get Started button clicked");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.navigate().back();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement getStarted2 = driver.findElement(By.xpath("//a[@class='btn btn-shootproof btn-shootproof-white google-ads-signup-tracking']"));
		js.executeScript("arguments[0].scrollIntoView();", getStarted2);
		boolean get = getStarted2.isDisplayed();
		System.out.println("Get Started button is :"+get);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", getStarted2);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println( "Bottommost Get Started button clicked");
		driver.quit();
	}
}
